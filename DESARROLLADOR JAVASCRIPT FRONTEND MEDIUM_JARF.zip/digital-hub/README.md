I used `npx create-react-app my-app`
to create the project and use react-router-dom for route management.


## How to test?

### have installed nodejs

Inside project run
### `yarn install`

and 

### `yarn start`