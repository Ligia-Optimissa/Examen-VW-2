import React from 'react';

export default () => {
    return (
        <h3>404 - Not Found</h3>
    );
}