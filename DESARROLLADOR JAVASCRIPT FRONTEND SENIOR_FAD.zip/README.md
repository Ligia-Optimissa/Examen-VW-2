//***************Steps to execute****************//
* Please to execute the project follow the next steps:

1.- open terminal and navigate to the project directory
2.- execute (npm install) to install dependencies
3.- execute (npm run json:server) to execute the fake server
4.- in other terminal execute (npm start) to initialize the react application


//***************** Approach*********************//

Based on the fact that is a small application and we are not working with a lot of components and pages,
the application has a separated shared folder structure, this helps to find files easily and allow us to reuse code.
Inside the src:
* Folder components - All components used in any page
* Folder global - utility functions in this case routes
* Folder pages - Each page of the application
* Folder servcies - Services used to connect to db, in this case fake db, in this place we create the HTTP Request and manage them
(This folder structure is not the best way for medium or big applications, because of the component number increase)

The application manage a global state (for a bigger application we can use REDUX to manage state): 
* authUser - logged in user
* isLoggedIn - boolean based on logged in or not
* toAccounts - all accounts 
* transactionsByToAccount - all transactions by toAccout
* transactions - all transaction
