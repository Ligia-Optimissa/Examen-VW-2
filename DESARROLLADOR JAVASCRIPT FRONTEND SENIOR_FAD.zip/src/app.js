// Import react and react dom libreries
import React, {Component} from 'react';
import Routes from './global/routes'
import { NavBar } from './components'
import { BrowserRouter as Router } from "react-router-dom";
import transactionService from './sevices/transaction/transaction.service';
import * as _ from 'lodash';
import './app.css';

// Create react component
class App extends Component {
  constructor(props) {
    super(props);
    // Global state
    this.state = {
      authUser: '',
      isLoggedIn: false,
      toAccounts: [],
      fromAccounts: [],
      transactionsByToAccount: [],
      transactionsByFromAccount: [],
      transactions: []
    }
  }

  /**
   * Function to execute just after component mounts
   */
  componentDidMount() {
    // Get all transactions from db json-server
    transactionService.getAllTransactions().then(res => {
      this.setState({
        transactions: res.data,
        transactionsByToAccount: _.groupBy(res.data, (transaction) => {return transaction.toAccount}),
        transactionsByFromAccount: _.groupBy(res.data, (transaction) => {return transaction.fromAccount}),
        toAccounts: _.uniq(_.map(res.data, (transaction) => transaction.toAccount)),
        fromAccounts: _.uniq(_.map(res.data, (transaction) => transaction.fromAccount))
      });
    });
  }

  /**
   * Function to execute when new transfer is created
   * this update the global state and execute service
   */
  handleNewTransfer = (newTransfer) => {
    const nt = {
      "fromAccount": newTransfer.fromAccount,
      "toAccount": newTransfer.toAccount,
      "amount": {
        "currency": '$',
        "value": parseInt(newTransfer.amount)
      },
      "sentAt": new Date()
    }
    // update global state
    this.setState(prevState => ({
      transactions: [...prevState.transactions, nt],
      transactionsByToAccount:_.groupBy([...prevState.transactions, nt], (transaction) => {return transaction.toAccount})
    }));
    // create transaction via service
    transactionService.createTransaction(nt).then((res) => {
      console.log('Transaction created...');
    }).catch((err)=> {
      console.log('Error creating transaction...');
    });
  }

  /**
   * Function to execute from children to set global state
   * @param username
   */
  handlerLogin = (username) => {
    this.setState({authUser: username, isLoggedIn: true});
  };

  /**
   * Fucntion to handle logout
   */
  handlerLogout = () => {
    this.setState({
      authUser: '',
      isLoggedIn: false,
      toAccounts: [],
      fromAccount: [],
      transactionsByToAccount: [],
      transactionsByFromAccount: [],
      transactions: []
    });
  };

  render() {
    return (
      <div className="app-content">
        <Router>
          <NavBar
            isLoggedIn={this.state.isLoggedIn}
            handlerLogout={this.handlerLogout}
          />
          <Routes
            handlerLogin={this.handlerLogin}
            isLoggedIn={this.state.isLoggedIn}
            authUser={this.state.authUser}
            toAccounts={this.state.toAccounts}
            fromAccounts={this.state.fromAccounts}
            transactionsByToAccount={this.state.transactionsByToAccount}
            transactionsByFromAccount={this.state.transactionsByFromAccount}
            handleNewTransfer={this.handleNewTransfer}
          />
        </Router>
      </div>
    );
  }
}

export default App;
