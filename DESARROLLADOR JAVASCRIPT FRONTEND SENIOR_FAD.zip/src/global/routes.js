import React from 'react';
import {LoginPage, HomePage, TransfersPage} from '../pages';

import {
  Switch,
  Route
} from "react-router-dom";

const Routes = (props) => {
  return (
    <Switch>
      <Route path="/home">
        <HomePage
          isLoggedIn={props.isLoggedIn}
          authUser={props.authUser}
          toAccounts={props.toAccounts}
          transactionsByToAccount={props.transactionsByToAccount}
          transactionsByFromAccount={props.transactionsByFromAccount}/>
      </Route>
      <Route path="/transfers">
        <TransfersPage
          isLoggedIn={props.isLoggedIn}
          authUser={props.authUser}
          toAccounts={props.toAccounts}
          fromAccounts={props.fromAccounts}
          transactionsByToAccount={props.transactionsByToAccount}
          handleNewTransfer={props.handleNewTransfer}/>
      </Route>
      <Route path="/">
        <LoginPage handlerLogin={props.handlerLogin}/>
      </Route>
    </Switch>
  );
};

export default Routes;
