import React from 'react';
import * as _ from 'lodash';
import moment from 'moment';
import './tableCard.component.css';

const TableCard = (props) => {
  return (
    <div className="table-card">
      <div className="table-card-header">
        <h2>{props.title}</h2>
      </div>
      <div className="table-card-body">
        <DataTable data={props.data} dataFrom={props.dataFrom} headers={props.headers}></DataTable>
      </div>
    </div>
  );
}

const DataTable = (props) => {
  const renderTableData = (data) => {
    return _.map((data), account => {
      const accountNumber = _.uniq(_.map(account, 'toAccount'))[0].toString(10);
      const totalAmount = _.reduce(_.map(account, 'amount.value'), (totalAmount, amount) => totalAmount + amount);
      const totalTransferred = _.reduce(_.map(props.dataFrom[accountNumber], 'amount.value'), (totalTransferred, amount) => totalTransferred + amount);
      const currency =  _.uniq(_.map(account, 'amount.currency'))[0];
      const latestDate = _.max(_.uniq(_.map(account, 'sentAt')));
      const total = (totalAmount- (!!totalTransferred ? totalTransferred : 0)).toFixed(2);
      return (
        <tr key={accountNumber}>
          <td className="data-table-td">*****{accountNumber.substr(5, 4)}</td>
          <td className="data-table-td">{currency}{total}</td>
          <td className="data-table-td">{moment(latestDate).format('DD/MMM/YY')}</td>
        </tr>
      )
    });
  }

  return (
    <table>
      <thead>
        <tr>
          {
            props.headers.map((header, index) => <th className="data-table-th" key={index}>{header}</th>)
          }
        </tr>
      </thead>
      <tbody>
        {renderTableData(props.data)}
      </tbody>
    </table>
  );
}

export default TableCard;