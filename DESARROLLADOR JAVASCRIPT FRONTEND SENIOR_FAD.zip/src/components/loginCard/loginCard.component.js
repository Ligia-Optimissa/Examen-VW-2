import React, {Component} from 'react';
import "./loginCard.component.css";
import { Redirect } from "react-router-dom";

export default class LoginCard extends Component {
  // Constructor
  constructor(props) {
    super(props);
    this.state = {
      username: '',
      usernameError: true,
      psw: '',
      pswError: true,
      redirect: false
    }
  }

  /**
   * Funtion to execute on username change
   * @param event
   */
  handleChangeUsername = (event) => {
    const username = event.target.value;
    setTimeout(() => {
      if(username.match('^[a-zA-Z0-9!"$%&/]{8,20}$') != null){
        this.setState({
          username: username,
          usernameError: false,
        });
      } else {
        this.setState({
          username: "",
          usernameError: true
        });
      }
    }, 1000);
  };

  /**
   * Function to execute on password change
   * @param event
   */
  handleChangePassword = (event) => {
    const psw = event.target.value;
    setTimeout(() => {
      if(psw.match('(?=.*[a-z])(?=.*[A-Z])(?=.*[!"$%&/])[a-zA-Z0-9!"$%&/]{8,20}$') != null) {
        // get numbers in string and store in array
        const numbers = psw.match(/\d+/g) ? psw.match(/\d+/g).map(Number) : [];
        this.numberSequence(numbers).then((sequenceNumbers) => {
          if(!sequenceNumbers) {
            this.setState({
              psw: psw,
              pswError: false,
            });
          } else {
            this.setState({
              psw: "",
              pswError: true
            });
          }
        });
      } else {
        this.setState({
          psw: "",
          pswError: true
        });
      }
    }, 1000);
  };

  /**
   * Function to validate array of numbers sequence
   * @param numbers
   * @returns {Promise<>}
   */
  numberSequence = (numbers) => {
    return new Promise((resolve) => {
      // foreach group of numbers in string
      numbers.map((number) => {
        const numStr = number.toString();
        const arrNums = numStr.split('');
        return arrNums.map((number, i) => {
          if(i < arrNums.length - 1) {
            if (arrNums[i+1] - 1 === parseInt(number)){
              resolve (true)
            }
          }
        });
      });
      resolve(false)
    });
  };

  /**
   * Function to execute on submit
   */
  handleSubmit = (e) => {
    e.preventDefault();
    this.props.handlerLogin(this.state.username);
    this.setState({
      redirect: true
    });
  };

  render() {
    const goHome = this.state.redirect;

    if(goHome) {
      return <Redirect to='/home'/>;
    }
    return (
      <div className="login-card">
        <h2 className="login-card-title">Login</h2>
        <form onSubmit={this.handleSubmit}>
          <div className="login-card-input-group">
            <input
              className="login-card-input"
              type="text"
              id="username"
              onBlur={this.handleChangeUsername}
              placeholder="Username"/>
            <input
              className="login-card-input"
              type="password"
              id="password"
              onBlur={this.handleChangePassword}
              placeholder="Password"/>
          </div>
          <input type="submit" value="Enter" className="login-card-submit-btn" disabled={this.state.usernameError || this.state.pswError}/>
        </form>
      </div>
    );
  }
}
