import React, { PureComponent } from 'react';
import * as _ from 'lodash';
import {
  PieChart, Pie, Sector, Cell,
} from 'recharts';

let data = [];

const COLORS = ['#B2DFDB', '#E53935', '#01579B'];

const RADIAN = Math.PI / 180;

const renderCustomizedLabel = ({
  cx, cy, midAngle, innerRadius, outerRadius, percent, index,
}) => {
  const radius = innerRadius + (outerRadius - innerRadius) * 0.5;
  const x = cx + radius * Math.cos(-midAngle * RADIAN);
  const y = cy + radius * Math.sin(-midAngle * RADIAN);
  return (
    <text x={x} y={y} fill="white" textAnchor={x > cx ? 'start' : 'end'} dominantBaseline="central">
      {data[index].value}
    </text>
  );
};

export default class CPieChart extends PureComponent {
  constructor(props) {
    super(props);
  }

  render() {
    data = [];
    // for each account count number of transaction
    _.map(this.props.dataChart, account => {
      const accountNumber = _.uniq(_.map(account, 'toAccount'))[0].toString(10);
      const transactionNum = account.length;
      data.push({
        name: accountNumber,
        value: transactionNum
      });
    });
    // width and height for view
    const cwidth = parseInt(this.props.cwidth);
    const cheight = parseInt(this.props.cheight);
    return (
      <PieChart width={cwidth} height={cheight}>
        <Pie
          data={data}
          cx={cwidth/2}
          cy={cheight/2}
          labelLine={false}
          label={renderCustomizedLabel}
          outerRadius={80}
          fill="#8884d8"
          dataKey="value"
        >
          {
            data.map((entry, index) => <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />)
          }
        </Pie>
      </PieChart>
    );
  }
}
