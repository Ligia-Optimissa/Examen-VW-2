import React from 'react';
import {CPieChart} from '../index'
import './dataCard.component.css';

const DataCard = (props) => {
  return (
    <div className="data-card">
      {
        props.showPieChart &&
        <div className="data-card-graph">
          <CPieChart cwidth="200" cheight="200" dataChart={props.dataChart}></CPieChart>
        </div>
      }
     {
        props.showImg &&
        <div className="data-card-img">
          <h3>320x200</h3>
        </div>
      }
      <div className="data-card-header">
        <h2>{props.title}</h2>
      </div>
      <div className="data-card-body">
        <p>{props.description}</p>
      </div>
    </div>
  );
}

export default DataCard;