import React from 'react';
import {NavLink} from "react-router-dom";
import './navbar.component.css';

const navbar = (props) => {
  return (
    <nav>
      <div className="navbar-container">
        <div className="flex-1">
          <div className="navbar-option">
            <div className="option-text">
              Company
            </div>
          </div>
        </div>
        {
          props.isLoggedIn &&
          <div className="flex-1">
            <div className="navbar-option">
              <NavLink activeClassName='is-active' to="/home" className="option-text">Home</NavLink>
            </div>
          </div>
        }
        {
          props.isLoggedIn &&
          <div className="flex-1">
            <div className="navbar-option">
              <NavLink activeClassName='is-active' to="/transfers" className="option-text">Transfers</NavLink>
            </div>
          </div>
        }
        {
          props.isLoggedIn &&
          <div className="flex-10">
            <div className="navbar-option-end">
              <NavLink to="/" className="option-text" onClick={props.handlerLogout}>Logout</NavLink>
            </div>
          </div>
        }
      </div>
    </nav>
  );
};

export default navbar;
