import React, {Component} from 'react';
import * as _ from 'lodash';
import moment from 'moment';
import './tableTransactionHistory.component.css'

export default class TableTransactionHistory extends Component {
  constructor(props){
    super(props);
  }

  renderTableData = (transactions) => {
    return transactions.map((transaction, index) => {      
      const originAccount = (transaction.fromAccount).toString(10);
      const destinationAccount = (transaction.toAccount).toString(10);
      const totalAmount = transaction.amount.value;
      const currency = transaction.amount.currency;
      const date = transaction.sentAt;

      return (
        <tr key={index}>
          <td className="data-table-td">*****{originAccount.substr(5, 4)}</td>
          <td className="data-table-td">{destinationAccount}</td>
          <td className="data-table-td">{moment(date).format('DD/MMM/YY')}</td>
          <td className="data-table-td">{currency}{totalAmount}</td>
          
        </tr>
      );
    });
  }

  renderTables = () => {
    return _.map(this.props.transactionsByToAccount, (transactions, index) => {
      return(
        <table key={index} className="transaction-history-table">
          <thead>
            <tr>
              <th className="transaction-history-table-th">Origin Account</th>
              <th className="transaction-history-table-th">Destination Account</th>
              <th className="transaction-history-table-th">Transfer Date</th>
              <th className="transaction-history-table-th">Amount</th>
            </tr>
          </thead>
          <tbody>
            { this.renderTableData(transactions) }
          </tbody>
        </table>
      );
    });
  }

  render() {
    return(
      <div className="transaction-history-tables">
        {this.renderTables()}
      </div>
    );
  }
}
