import React from 'react';
import './welcomeMsg.component.css';

const WelcomeMsg = (props) => {
  return(
    <h1 className="welcome-message-text">Welcome to your online banking {props.authUser}</h1>
  );
};

export default WelcomeMsg;