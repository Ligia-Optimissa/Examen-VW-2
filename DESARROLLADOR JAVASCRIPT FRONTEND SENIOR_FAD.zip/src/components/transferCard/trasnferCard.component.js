import React, {Component} from 'react';
import './transferCard.component.css';

export default class TransferCard extends Component {
  constructor(props) {
    super(props);
    this.state = {
      fromAccount: '',
      fromAccountError: true,
      toAccount: '',
      toAccountError: true,
      amount: 0,
      amountError: true
    }
  }

  handleChangeOriginAccount = (event) => {
    const fromAccount = event.target.value;
    if(fromAccount.match('^[a-zA-Z0-9]{1,20}$') != null){
      this.setState({
        fromAccount: fromAccount,
        fromAccountError: false,
      });
    } else {
      this.setState({
        fromAccount: '',
        fromAccountError: true,
      });
    }
  } 

  handleChangeDestinationAccount = (event) => {
    const toAccount = event.target.value;
    if(toAccount.match('^[0-9]{1,20}$') != null){
      this.setState({
        toAccount: toAccount,
        toAccountError: false,
      });
    } else {
      this.setState({
        toAccount: '',
        toAccountError: true,
      });
    }
  }

  handleChangeAmount = (event) => {
    const amount = event.target.value;
    if(amount.match('^[0-9]{1,20}$') != null){
      this.setState({
        amount: amount,
        amountError: false,
      });
    } else {
      this.setState({
        amount: 0,
        amountError: true,
      });
    }
  }

  handleSubmit = (e) => {
    e.preventDefault();
    const newTransfer = {
      fromAccount: parseInt(this.state.fromAccount),
      toAccount: parseInt(this.state.toAccount),
      amount: this.state.amount
    }
    this.props.handleNewTransfer(newTransfer);
    this.resetForm();
  }
  
  handleCancelSubmit = (e) => {
    e.preventDefault();
    this.setState({
      fromAccount: '',
      fromAccountError: true,
      toAccount: '',
      toAccountError: true,
      amount: 0,
      amountError: true
    });

    this.resetForm();
  }

  resetForm = () => {
    document.getElementById("transfer-card-form").reset();
  }

  render() {
    return (
      <div className="transfer-card">
        <h2 className="transfer-card-title">Create New Transfer</h2>
        <form id="transfer-card-form">
          <div className="trasnfer-card-input-group">
            <label className="transfer-card-label">
              Select origin account
            </label>
            <select id="cars" name="carlist" form="carform" className="transfer-card-input" onChange={this.handleChangeOriginAccount}>
              <option value=""></option>
              {
                this.props.originAcounts.map((originAccount, index)  => {
                  return <option key={index} value={originAccount}>*****{originAccount.toString().substr(5, 4)}</option>
                })
              }
            </select>
          </div>
          <div className="trasnfer-card-input-group">
            <label className="transfer-card-label">
              Destination account
            </label>
            <input
              className="transfer-card-input" type="number" onChange={this.handleChangeDestinationAccount}></input>
          </div>
          <div className="trasnfer-card-input-group">
            <label className="transfer-card-label">
              Amount
            </label>
            <input
              className="transfer-card-input" type="number" onChange={this.handleChangeAmount}></input>
          </div>
          <div className="transfer-card-btns">
            <button
              className="transfer-card-btn transfer-btn" 
              disabled={this.state.amountError || this.state.fromAccountError || this.state.toAccountError}
              onClick={this.handleSubmit}>
              Transfer
            </button>
            <button className="transfer-card-btn cancel-btn" onClick={this.handleCancelSubmit}>Cancel</button>
          </div>
        </form>
      </div>
    );
  }
}