const axios = require('axios').default;

/**BASE API */
const API = "http://localhost:3004"
/************/

/**
 * Function to get all transactions
 */
const getAllTransactions = () => {
  return axios.get(API + '/transactions');
};

/**
 * Function to create a new transaction
 */
const createTransaction = (newTransaction) => {
  return axios.post(API + '/transactions', newTransaction, {
    headers:{
      'Content-Type': 'application/json'
    }
  });
}

export default {
  getAllTransactions,
  createTransaction
}