import React, { Component } from 'react';
import { Redirect } from "react-router-dom";
import {WelcomeMsg, DataCard, TableCard} from '../../components';
import * as _ from 'lodash';
import './homePage.css';

class HomePage extends Component {
  constructor(props) {
    super(props);
  }
  
  render() {
    if(!this.props.isLoggedIn) {
      return <Redirect to='/'/>;
    }
    return (
      <div className="home-page">
        <WelcomeMsg authUser={this.props.authUser}/>
        <div className="home-page-cards">
          <DataCard
            showPieChart="true"
            dataChart={this.props.transactionsByToAccount}
            title="Transactions History"
            description="Lorem ipsum dolor sit amet, consectetur adipiscing elit,
              sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
              Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris
              nisi ut aliquip ex ea commodo consequat.">
          </DataCard>
          <DataCard
            showImg="true"
            title="Transactions History"
            description="Lorem ipsum dolor sit amet, consectetur adipiscing elit,
              sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
              Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris
              nisi ut aliquip ex ea commodo consequat.">
          </DataCard>
          <TableCard
            title="Current Balance"
            data={this.props.transactionsByToAccount}
            dataFrom={this.props.transactionsByFromAccount}
            headers={['Account No.', 'Balance', 'Date of latest transfer']}
            >
          </TableCard>
        </div>
      </div>
    );
  }
}

export default HomePage;
