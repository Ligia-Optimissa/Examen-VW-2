export {default as LoginPage} from './Login/loginPage';
export {default as HomePage} from './Home/homePage';
export {default as TransfersPage} from './Transfers/transfersPage';
