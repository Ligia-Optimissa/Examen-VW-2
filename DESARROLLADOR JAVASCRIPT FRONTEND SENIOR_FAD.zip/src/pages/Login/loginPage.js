import React from 'react';
import './loginPage.css';
import {LoginCard} from "../../components";

/**
 * Login Page component
 * @returns {*}
 * @constructor
 */
const LoginPage = (props) => {
  return (
    <div className="login-page">
      <LoginCard handlerLogin={props.handlerLogin}/>
    </div>
  );
};

export default LoginPage;
