import React, { Component } from 'react';
import { Redirect } from "react-router-dom";
import {CPieChart, TransferCard, TableTransactionHistory} from '../../components';
import * as _ from 'lodash';
import "./transfersPage.css";

class TransfersPage extends Component {
  constructor(props) {
    super(props);
    this.state = {
      toAccounts: [],
      transactionsByToAccount: [],
      transactions: []
    }
  }

  render() {
    if(!this.props.isLoggedIn) {
      return <Redirect to='/'/>;
    }
    return (
      <div className="transfers-page">
        <div className="transfers-page-row">
          <div className="transfers-page-form">
            <TransferCard
              originAcounts={this.props.fromAccounts}
              destinationAccounts={this.props.toAccounts}
              handleNewTransfer={this.props.handleNewTransfer}></TransferCard>
          </div>
          <div className="transfers-page-chart">
            <CPieChart cwidth="250" cheight="250" dataChart={this.props.transactionsByToAccount}></CPieChart>
          </div>
        </div>
        <div className="transfers-page-column">
          <TableTransactionHistory transactionsByToAccount={this.props.transactionsByToAccount}></TableTransactionHistory>
        </div>
      </div>
    )
  }
}

export default TransfersPage;
